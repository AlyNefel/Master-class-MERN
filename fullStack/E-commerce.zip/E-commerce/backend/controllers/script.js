
let array = [1,2,8]
for (let index = 0; index < array.length; index++) {
    const element = array[index];
    console.log(element)
}