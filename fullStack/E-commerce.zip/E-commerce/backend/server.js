import express from "express"
import dotenv from "dotenv"
import connectDb from "./config/db_config.js"
import cors from "cors"
import router from "./routes/userRoutes.js"
import categoryRouter from "./routes/categoryRoutes.js"
import productRouter from "./routes/productRoutes.js"

import shopRouter from "./routes/shopRoutes.js"
//we will call dontenv config 

dotenv.config()
// instance of express 
const app = express()
app.use(cors())
// app.use(cors({origin:"http://localhost:5173"}))

app.use(express.json())
app.use("/api/users",router)
app.use("/api/categories",categoryRouter)
app.use("/api/products",productRouter)
app.use("/api/shops",shopRouter)
// invoke the db connection 
connectDb()

const port = process.env.PORT || 5000

app.listen(port,()=>{
    console.log(`the server is running on port ${port}`)
})

