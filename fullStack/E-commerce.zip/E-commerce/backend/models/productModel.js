import mongoose from "mongoose"

const productSchema =new mongoose.Schema({
productName:{
    type:String,
    required:[true,"please enter product name !"]
},
productDescription:{
    type:String,
    // required:[true,"please enter product description !"]
},
productPrice:{
    type:Number,
    required:[true,"please enter product price !"]
},
category:{
    type:mongoose.Schema.Types.ObjectId,//15
    ref:'Category',
    required:true
},
shop:{
type:mongoose.Schema.Types.ObjectId,//15
    ref:'Shop',
    required:true
},
numberInStock:{
    type:Number,
    // required:[true,"Please enter quantity in stock!"]
},
createdBy:{
    type:mongoose.Schema.Types.ObjectId,
    ref:'User',
    required:true
},
isPublished:{
type:Boolean,
default:false
},
reviews:[
    {
    user:{
    type:mongoose.Schema.Types.ObjectId,
    ref:'User',
    required:true
    }
    ,
    comment:{
    type:String,
    required:true
    }
    }
],
image:{
url:String,
public_id:String
}

},{
    timestamps:true
})

const Product =mongoose.model('Product',productSchema)

export default Product;